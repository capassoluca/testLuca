<?php

namespace PKPass;

use Exception;

class PKPassException extends Exception
{

}
